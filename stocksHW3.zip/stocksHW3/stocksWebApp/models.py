from django.db import models
from django.contrib.auth import get_user_model
# from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
# from .models import Portfolio

User = get_user_model()

# Stock model
class Stock(models.Model):
    symbol = models.CharField(max_length=10, unique=True)
    
    def __str__(self):
        return self.symbol

class StockPrice(models.Model):
    # Follows the example below from AAPL. Creates another DB table with the stock symbol as a foreign key
    # {
    #         "open": 136.60000610351562,
    #         "high": 137.3300018310547,
    #         "low": 135.75999450683594,
    #         "close": 137.27000427246094,
    #         "adjclose": 135.14633178710938,
    #         "volume": 52485800,
    #         "ticker": "AAPL",
    #         "date": "2021-07-01"
    # }
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE, related_name='prices')
    open_price = models.DecimalField(max_digits=20, decimal_places=10)
    high_price = models.DecimalField(max_digits=20, decimal_places=10)
    low_price = models.DecimalField(max_digits=20, decimal_places=10)
    close_price = models.DecimalField(max_digits=20, decimal_places=10)
    adj_close = models.DecimalField(max_digits=20, decimal_places=10)
    volume = models.BigIntegerField()
    date = models.DateField()

    def __str__(self):
        return f"{self.stock.symbol} - {self.date}"


# Portfolio model
class Portfolio(models.Model):
    # Connect to current user
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='portfolio')
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)


# Holding model to represent held stock
class Holding(models.Model):
    # Connect to portfolio
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name='holdings')
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=0)
    value = models.DecimalField(max_digits=20, decimal_places=10, default=0)

# Define Transactions
class Transaction(models.Model):
    BUY = 'BUY'
    SELL = 'SELL'
    TRANSACTION_TYPE_CHOICES = [
        (BUY, 'Buy'),
        (SELL, 'Sell')
    ]
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name='transactions')
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    transaction_type = models.CharField(max_length=4, choices=TRANSACTION_TYPE_CHOICES)
    transaction_price = models.DecimalField(max_digits=20, decimal_places=10)
    transaction_date = models.DateTimeField(auto_now_add=True)

    @property
    def transaction_amount(self):
        return self.quantity * self.transaction_price
    
# WHen a new user is created, establish a portfolio 
# that's connected to the user and a initial balance of fake currency
@receiver(post_save, sender=User)
def create_portfolio(sender, instance, created, **kwargs):
    if created:
        Portfolio.objects.create(user=instance, balance=10000)
        print(f"Portfolio created for user: {instance.username}")
        print(instance.portfolio)


# connecte signal handler function
post_save.connect(create_portfolio, sender=User)

    

