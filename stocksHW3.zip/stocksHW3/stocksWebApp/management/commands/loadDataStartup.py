from django.core.management.base import BaseCommand
from stocksWebApp.helpers import load_stock_data_from_json

class Command(BaseCommand):
    help = 'Load stock data from JSON file into the database on startup'
    def handle(self, *args, **options):
        dataPath = r"C:\Users\NC\Documents\Rutgers\Grad\SWE for Web Apps\HW\Assignment 3 - Stocks Webapp\stocksHW3\summerMonths_stock_data.json"
        load_stock_data_from_json(dataPath)
        print("Done loading stock data")
