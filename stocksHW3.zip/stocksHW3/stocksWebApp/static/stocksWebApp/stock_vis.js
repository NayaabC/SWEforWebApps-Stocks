// Load data from JSON file
d3.json(dataJSON).then(function(data) {
    // console.log(data);
    var tickers = Object.keys(data);
    
    // Create a dropdown menu to select stocks
    var dropdown = d3.select('.chart')
        .append('select')
        .on('change', function() {
            updateChart(this.value);
        });

    dropdown.selectAll('option')
        .data(tickers)
        .enter().append('option')
        .attr('value', d => d)
        .text(d => d);

    // Initial stock selection
    var initialStock = tickers[0];
    updateChart(initialStock);

    function updateChart(selectedStock) {
        // console.log(selectedStock);
        d3.selectAll('.chart-svg').remove();

        var stockData = data[selectedStock];

        // Create SVG container for the selected stock
        var svg = d3.select('.chart')
            .append('svg')
            .attr('class', 'chart-svg')
            .attr('width', 500)
            .attr('height', 300);

        // Define scales
        var xScale = d3.scaleLinear()
            .domain([0, stockData.length - 1])
            .range([0, 500]);

        var yScale = d3.scaleLinear()
            .domain([d3.min(stockData, d => d.adjclose), d3.max(stockData, d => d.adjclose)])
            .range([300, 0]);

        // Define line function
        var line = d3.line()
            .x((d, i) => xScale(i))
            .y(d => yScale(d.adjclose));

        // Append path for the line
        svg.append('path')
            .data([stockData])
            .attr('class', 'line')
            .attr('fill', 'none')
            .attr('stroke', 'steelblue')
            .attr('stroke-width', 1.5)
            .attr('d', line);

        // Append text for the ticker
        svg.append('text')
            .attr('x', 10)
            .attr('y', 10)
            .attr('fill', 'black')
            .text(selectedStock);
    }
}).catch(function(error) {
    console.log(error);
});
