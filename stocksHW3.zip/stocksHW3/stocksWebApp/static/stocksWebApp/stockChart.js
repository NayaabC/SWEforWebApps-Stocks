var stocksPath = "C:\Users\NC\Documents\Rutgers\Grad\SWE for Web Apps\HW\Assignment 3 - Stocks Webapp\stocksHW3\stocksWebApp\static\stocksWebApp\images\d3_data\d3_predictions.csv";
var data = $.csv.toObjects(stocksPath);

console.log(data);