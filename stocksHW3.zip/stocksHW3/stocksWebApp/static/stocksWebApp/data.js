let allData;
var qtyInput;
var decrementButton;
var incrementButton;


function changeQuantity(direction) {
    var currentValue = qtyInput.value ? parseInt(qtyInput.value) : 0;
    if (direction === 0) {
        qtyInput.value = currentValue > 0 ? currentValue - 1 : 0;
    } else {
        qtyInput.value = currentValue + 1;
    }
    console.log("Stock Trade Quantity Change: ", qtyInput.value);
}

// Switch between the SVG and the Matplotlib generated plot of the LSTM outputs
// if imgSymbol is another symbol, it should just update the source
// meaning that the user is currently switching which stock to view.
function toggleChart(imgSymbol='') {
    var svgElement = document.getElementById('chart-svg');
    var imageElement = document.getElementById('chart-image');
    var toggleButton = document.getElementById('toggle-chart');
    var stockSymbol = document.getElementById('stock').value;

    if (imgSymbol !== '') {
        imageElement.src = imagePath + imgSymbol + "-LSTM-closing.png";;
    } else {
        if (svgElement.style.display === 'none') {
            svgElement.style.display = 'block';
            imageElement.style.display = 'none';
            toggleButton.textContent = 'Show Image';
        } else {
            svgElement.style.display = 'none';
            imageElement.style.display = 'block';
            toggleButton.textContent = 'Show SVG';

            // var imagePath = "{% static 'stocksWebApp/images/LSTM_test/' %}" + stockSymbol + "-LSTM-closing.png";
            imageElement.src = imagePath + stockSymbol + "-LSTM-closing.png";;
        }
    }   
}

document.addEventListener("DOMContentLoaded", function () {
    const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;
    // Load CSV stocks data
    fetch('/stocksWebApp/api/stocksCSV').then(response => response.text())
        .then(data => {
            allData = d3.csvParse(data);
            const parseDate = d3.timeParse("%Y-%m-%d");
            allData.forEach(d => {
                d.Date = parseDate(d.Date);
                // d.Close = +d.Close;
            });
            // console.log(allData);
        })
        .catch(error => {
            console.error('Error handling CSV data: ', error);
        });
    document.getElementById("stock-selection-form").addEventListener("change", function (event) {
        // event.preventDefault(); // Prevent the default form submission
        
        // Get the selected stock symbol
        var selectedStock = document.getElementById("stock").value;
        // Make an API call using JavaScript (for example, using fetch)
        fetch("/stocksWebApp/api/process_selection", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": csrfToken,
            },
            body: JSON.stringify({ stock: selectedStock })
        })
        .then(function (response) {
            if (response.ok) {
                // Handle successful response
                // console.log("Stock selection processed successfully!");
                return response.json();
            } else {
                // Handle error response
                console.error("Error processing stock selection:", response.statusText);
            }
        })
        .then(function (data) {
            updateChart(data);
            // showToggle(data);
            toggleChart(imgSymbol=data.stock);
        })
        .catch(function (error) {
            // Handle network errors
            console.error("Network error:", error);
        });
    });

    // Toggle between SVG and LSTM output
    // function showToggle(data) {
    //     const selectedStock = data.stock;
    //     const toggleButton = document.getElementById('toggle-chart');
    //     const chartContainer = document.getElementById('chart-container');
    //     let svgShown = true;

    //     toggleButton.addEventListener('click', () => {
    //         if (svgShown) {
    //             // Hide SVG
    //             chartContainer.innerHTML = '';
    //             const imagePath = 'C:\\Users\\NC\\Documents\\Rutgers\\Grad\\SWE for Web Apps\\HW\\Assignment 3 - Stocks Webapp\\stocksHW3\\stocksWebApp\\static\\stocksWebApp\\images\\LSTM_test\\' + selectedStock + '-LSTM-closing.png';
    //             const image = document.createElement('img');
    //             image.src = imagePath;
    //             chartContainer.appendChild(image);
    //             toggleButton.textContent = 'Show SVG';
    //             svgShown = false;
    //         } else {
    //             // Show SVG, hide image
    //             chartContainer.innerHTML = '';
    //             toggleButton.textContent = 'Show Image';
    //             svgShown = true;
    //         }
    //     })

    // Updates the d3 JS chart based on mouse movement and Stock selection
    function updateChart(data) {
        console.log("Received Data: ", data);
        const selectedStock = data.stock;

        var stockData = allData.filter(d => d.Ticker === selectedStock);

        // console.log(stockData);
        const margin = {top: 70, right: 60, bottom: 50, left: 80};
        const width = 1600 - margin.left - margin.right;
        const height = 800 - margin.top - margin.bottom;
        let svg = d3.select("#chart-container svg");

        if (svg.empty()){
            svg = d3.select("#chart-container")
            .append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);
        } else {
            svg.selectAll("*").remove();
        }
        
        const xScale = d3.scaleTime()
            .domain(d3.extent(stockData, d => d.Date))
            .range([0, width]);
        
        const yScale = d3.scaleLinear()
            .domain([0, d3.max(stockData, d => + d.Close)])
            .range([height, 0]);
        
        const area = d3.area()
            .x(d => xScale(d.Date))
            .y0(height)
            .y1(d => yScale(d.Close));
        
        const line = d3.line()
            .x(d => xScale(d.Date))
            .y(d => yScale(d.Close));

        const gradient = svg.append("defs")
            .append("linearGradient")
            .attr("id", "gradient")
            .attr("x1", "0%")
            .attr("x2", "0%")
            .attr("y1", "0%")
            .attr("y2", "100%")
            .attr("spreadMethod", "pad");
        
        gradient.append("stop")
            .attr("offset", "0%")
            .attr("stop-color", "#85bb65")
            .attr("stop-opacity", 1);

        gradient.append("stop")
            .attr("offset", "100%")
            .attr("stop-color", "#85bb65")
            .attr("stop-opacity", 0);
        
        
        svg.append("path")
            .datum(stockData)
            .attr("class", "area")
            .attr("d", area)
            .style("fill", "url(#gradient)")
            .style("opacity", 0.5);
        
        svg.append("path")
            .datum(stockData)
            .attr("fill", "none")
            .attr("stroke", "green")
            .attr("stroke-width", 2)
            .attr("d", line);
        
        // Add axes
        svg.append("g")
            .attr("transform", `translate(0,${height})`)
            .call(d3.axisBottom(xScale))
            .selectAll("path, line")
            .style("stroke", "#ffcccc");

        svg.append("g")
            .call(d3.axisLeft(yScale))
            .selectAll("path, line")
            .style("stroke", "#ffcccc");

        svg.selectAll(".tick text")
            .style("fill", "#ffcccc");

        
        const tooltip = d3.select("body")
        .append("div")
        .attr("class", "tooltip");

        // Add circle element for tooltip
        const circle = svg.append("circle")
            .attr("r", 0)
            .attr("fill", "red")
            .style("stroke", "white")
            .attr("opacity", 0.7)
            .style("pointer-events", "none");
        
        const ttLineX = svg.append("line")
            .attr("class", "tooltip-line")
            .attr("id", "tooltip-line-x")
            .attr("stroke", "red")
            .attr("stroke-width", 1)
            .attr("stroke-dasharray", "2,2");
        
        const ttLineY = svg.append("line")
            .attr("class", "tooltip-line")
            .attr("id", "tooltip-line-y")
            .attr("stroke", "red")
            .attr("stroke-width", 1)
            .attr("stroke-dasharray", "2,2");
        
        // Mouse Pointer listening region rectangle
        const mouseListener = svg.append("rect")
            .attr("width", width)
            .attr("height", height)
            .style("fill", "none")
            .style("pointer-events", "all");


        const tooltipRawDate = d3.select("body")
            .append("div")
            .attr("class", "tooltip");

        mouseListener.on("mousemove", function (event) {
            const [xCoord] = d3.pointer(event, this);
            const bisectDate = d3.bisector(d => d.Date).left;
            const x0 = xScale.invert(xCoord);
            const i = bisectDate(stockData, x0, 1);
            const d0 = stockData[i - 1];
            const d1 = stockData[i];
            const d = x0 - d0.Date > d1.Date - x0 ? d1 : d0;
            const xPos = xScale(d.Date);
            const yPos = yScale(d.Close);

            // update circle position
            circle.attr("cx", xPos).attr("cy", yPos);

            circle.transition().duration(50).attr("r", 5);

            ttLineX.style("display", "block")
                .attr("x1", xPos)
                .attr("x2", xPos)
                .attr("y1", 0)
                .attr("y2", height);
            
            ttLineY.style("display", "block")
                .attr("y1", yPos)
                .attr("y2", yPos)
                .attr("x1", 0)
                .attr("x2", width);
            
            // tooltip.style("display", "block")
            //     .style("left", `${90}px`)
            //     .style("top", `${yPos + 68}px`)
            //     .html(`$${d.Close !== undefined ? d.Close : 'N/A'}`);
            
            // tooltipRawDate.style("display", "block")
            //     .style("left", `${xPos + 60}px`)
            //     .style("top", `${height + 53}px`)
            //     .html(`${d.Date !== undefined ? d.Date.toISOString().slice(0, 10) : 'N/A'}`);

            // Add Tooltip
            tooltip.style("display", "block")
                .style("left", `${xPos + 10}px`)
                .style("top", `${yPos + 500}px`)
                .style("color", "#ffcccc")
                .html(`<strong>Date: </strong> ${d.Date.toISOString().slice(0,10)}<br><strong>Closing Price: </strong> ${d.Close !== undefined ? d.Close : 'N/A'}`);
            
        });

        // mouse leave listening function
        mouseListener.on("mouseleave", function () {
            circle.transition().duration(50).attr("r", 0);
            tooltip.style("display", "none");
            // tooltipRawDate.style("display", "none");
            ttLineX.attr("x1", 0).attr("x2", 0);
            ttLineY.attr("y1", 0).attr("y2", 0);
            ttLineX.style("display", "none");
            ttLineY.style("display", "none");
        });
        document.getElementById("chart-container").style.display = "block";
        document.getElementById("trading-form").style.display = "block";

    }

    
    qtyInput = document.getElementById("quantity");
    decrementButton = document.getElementById("decrement");
    incrementButton = document.getElementById("increment");
    decrementButton.addEventListener("click", function() {
        changeQuantity(0);
    });

    incrementButton.addEventListener("click", function () {
        changeQuantity(1);
    });

    qtyInput.addEventListener("input", function (event) {
        const value = parseInt(event.target.value);
        if(isNaN(value) || value < 0) {
            event.target.value = 0;
        }
    });


    // Handle stock trading form submission
    document.getElementById("stock-trading-form").addEventListener("submit", function (event) {
        // Prevent default form submission
        event.preventDefault()

        var action = document.getElementById("action").value;
        var quantity = document.getElementById("quantity").value;
        var selectedStock = document.getElementById("stock").value;

        // Make API call to execute transaction
        fetch('/stocksWebApp/api/executeTransaction', {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": csrfToken
            },
            body: JSON.stringify({stock: selectedStock, action: action, quantity: quantity})
        })
        .then(function (response) {
            if (response.ok) {
                return response.json();
            } else {
                console.error("Error executing transaction", response.statusText);
            }
        })
        .then(data => {
            console.log("Transaction: ", data);
        })
        .catch(function (error) {
            console.error("Network error:", error);
        });
    });
});