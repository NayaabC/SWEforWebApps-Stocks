import json
from .models import Stock, StockPrice

def load_stock_data_from_json(file_path):
    with open(file_path) as f:
        data = json.load(f)
        for symbol, stock_data_list in data.items():
            # print("symbol: ", symbol)
            # print("stock_data_list: ", stock_data_list)
            stock, created = Stock.objects.get_or_create(
                symbol=symbol
            )
            for stock_data in stock_data_list:
                stock_price = StockPrice.objects.create(
                    stock=stock,
                    open_price=stock_data['open'],
                    high_price=stock_data['high'],
                    low_price=stock_data['low'],
                    close_price=stock_data['close'],
                    adj_close=stock_data['adjclose'],
                    volume=stock_data['volume'],
                    date=stock_data['date']
                )
