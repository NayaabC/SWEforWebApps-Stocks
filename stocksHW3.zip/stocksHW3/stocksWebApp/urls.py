from django.urls import path, include
from django.contrib import admin
from django.core.management import call_command
from . import views
from stocksWebApp.management.commands.loadDataStartup import Command

call_command(Command())

urlpatterns = [
    path('stocksWebApp/about/', views.about, name='about'),
    path('stocksWebApp/service/', views.service, name='service'),
    path('stocksWebApp/help/', views.help, name='help'),
    path('stocksWebApp/dataPresenting/', views.data_presenting, name='dataPresenting'),
    path('stocksWebApp/accounts/signup', views.SignUpView.as_view(), name='signup'),
    path('stocksWebApp/accounts/', include('django.contrib.auth.urls')),
    path('stocksWebApp/profile/', views.profile, name='profile'),
    path('stocksWebApp/api/process_selection', views.process_selection, name='process_selection'),
    path('stocksWebApp/api/stocksCSV', views.stocksCSV, name='stocksCSV'),
    path('stocksWebApp/api/executeTransaction', views.executeTransaction, name='executeTransaction')
]