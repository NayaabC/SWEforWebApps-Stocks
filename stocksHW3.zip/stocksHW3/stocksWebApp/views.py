from django.db import transaction
from django.db.models import Sum
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import CreateView
from .models import Stock, StockPrice, Holding, Portfolio, Transaction

import json

# Create your views here.
def about(request):
    return render(request, 'about.html')


def service(request):
    # Loads Stock Data from database before rendering the page
    stocks = Stock.objects.all()

    context = {
        'stock_data': stocks
    }
    print(context)
    
    return render(request, 'service.html', context)

def stocksCSV(request):
    stocksPath = r"C:\Users\NC\Documents\Rutgers\Grad\SWE for Web Apps\HW\Assignment 3 - Stocks Webapp\stocksHW3\stocksWebApp\static\stocksWebApp\images\d3_data\d3_predictions.csv"
    with open(stocksPath, mode='r') as file:
        data = file.read()
    return HttpResponse(data, content_type='text/csv')

def help(request):
    return render(request, 'help.html')

def data_presenting(request):
    return render(request, 'data_presenting.html')

def profile(request):
    return render(request, 'profile.html')

def process_selection(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            # print(data)
            stock_symbol = data.get('stock')
            return JsonResponse({'message': 'Stock Selection Processed Successfully!', 'stock': stock_symbol})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)


# BUY OR SELL using most recently available closing price
@csrf_exempt
@login_required
@transaction.atomic
def executeTransaction(request):
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            stock_symbol = data.get('stock')
            action = data.get('action')
            quantity = data.get('quantity')

            # get stock object from db
            stock = get_object_or_404(Stock, symbol=stock_symbol)
            stockPrice = get_object_or_404(StockPrice.objects.filter(stock=stock).order_by('-date')[:1])
            # print(stockPrice)
            total_cost = stockPrice.close_price * int(quantity)

            if action == 'buy':
                # User should only be able to buy if they have enough in their balance
                if request.user.portfolio.balance >= total_cost:
                    request.user.portfolio.balance -= total_cost
                    request.user.portfolio.save()

                    holdings = Holding.objects.filter(portfolio=request.user.portfolio, stock=stock)
                    total_qty = holdings.aggregate(total_qty=Sum('quantity'))['total_qty'] or 0
                    total_value = holdings.aggregate(total_value=Sum('value'))['total_value'] or 0

                    # update portfolio
                    holding, created = Holding.objects.get_or_create(
                        portfolio=request.user.portfolio,
                        stock=stockPrice.stock,
                        quantity=quantity,
                        value=total_value + total_cost
                    )
                    holding.quantity += quantity
                    holding.save()
                    # print(holding.portfolio)
                    # print(holding.value)
                    # print(holding.quantity)
                    return JsonResponse({
                        'message': 'Stock purchased successfully',
                        'stock': stock.symbol
                    })
                else:
                    return JsonResponse({'error': 'Insufficient Balance'}, status=400)
            elif action == 'sell':
                port = get_object_or_404(Portfolio, user=request.user)

                # aggregate all holdings of same stock to save time
                # NOTE - THIS needs to change if future updates are made
                holdings = Holding.objects.filter(portfolio=request.user.portfolio, stock=stock)
                total_qty = holdings.aggregate(total_qty=Sum('quantity'))['total_qty'] or 0
                total_value = holdings.aggregate(total_value=Sum('value'))['total_value'] or 0
                # holding = get_object_or_404(Holding,
                #     portfolio=port,
                #     stock=stock
                # )

                # User should only be able to sell if they have enough of that stock
                # print("total qty", total_qty)
                if int(total_qty) < int(quantity):
                    return JsonResponse({'error': 'Not enough shares to sell'}, status=400)
                
                sale = stockPrice.close_price * int(quantity)

                # update balance
                request.user.portfolio.balance += sale
                request.user.portfolio.save()

                # update holding
                try:
                    holding, _ = Holding.objects.get_or_create(
                        portfolio=request.user.portfolio,
                        stock=stock
                    )
                except:
                    holds = Holding.objects.filter(portfolio=request.user.portfolio, stock=stock)
                    hold = holdings.first()
                    holdings.exclude(pk=hold.pk).delete()
                    holding = hold
                
                holding.quantity -= int(quantity)
                holding.value -= sale
                holding.save()

                # Create transaction record
                Transaction.objects.create(
                    portfolio=request.user.portfolio,
                    stock=holding.stock,
                    quantity=quantity,
                    transaction_type=Transaction.SELL,
                    transaction_price=stockPrice.close_price
                )

                return JsonResponse({'message': 'Stock sold', 'stock': stock.symbol})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=406)
                


class SignUpView(CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = "registration/signup.html"

